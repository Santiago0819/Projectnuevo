package com.centrodeportivo.reservas.model;

import com.centrodeportivo.reservas.model.enums.MetodoPago;
import com.centrodeportivo.reservas.repository.CsvEntity;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Pago implements CsvEntity {

    private Long id;
    private Long reservaId;
    private MetodoPago metodo;
    private double monto;
    private LocalDateTime fechaHora;
}
