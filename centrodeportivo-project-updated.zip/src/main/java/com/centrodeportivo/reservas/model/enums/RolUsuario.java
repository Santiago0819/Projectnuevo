package com.centrodeportivo.reservas.model.enums;

public enum RolUsuario {
    SOCIO,
    EMPLEADO
}
