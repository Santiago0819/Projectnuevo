package com.centrodeportivo.reservas.model;

import com.centrodeportivo.reservas.model.enums.TipoInstalacion;
import com.centrodeportivo.reservas.repository.CsvEntity;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class Instalacion implements CsvEntity {

    private Long id;
    private String nombre;
    private TipoInstalacion tipo;
    private double tarifaHora;
    private List<Long> equiposIds = new ArrayList<>();
}
