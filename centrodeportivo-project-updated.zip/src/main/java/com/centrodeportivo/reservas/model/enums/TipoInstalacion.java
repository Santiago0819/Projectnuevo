package com.centrodeportivo.reservas.model.enums;

public enum TipoInstalacion {
    CANCHA_FUTBOL,
    CANCHA_TENIS,
    PISTA_ATLETISMO,
    SALA_MUSCULACION,
    PISCINA
}
