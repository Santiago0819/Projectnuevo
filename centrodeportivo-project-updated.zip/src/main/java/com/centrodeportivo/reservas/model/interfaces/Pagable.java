package com.centrodeportivo.reservas.model.interfaces;

public interface Pagable {
    double calcularTotal();
}
