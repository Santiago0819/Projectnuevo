package com.centrodeportivo.reservas.model;

import com.centrodeportivo.reservas.model.abstracto.Usuario;
import com.centrodeportivo.reservas.model.enums.RolUsuario;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class Empleado extends Usuario {

    private String cargo;
    private double salario;

    public Empleado() {
        setRol(RolUsuario.EMPLEADO);
    }

    @Override
    public double calcularDescuento(double tarifaBase) {
        return 0.0;
    }
}
