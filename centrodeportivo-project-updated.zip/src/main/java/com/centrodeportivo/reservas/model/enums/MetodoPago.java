package com.centrodeportivo.reservas.model.enums;

public enum MetodoPago {
    EFECTIVO,
    TARJETA,
    TRANSFERENCIA
}
