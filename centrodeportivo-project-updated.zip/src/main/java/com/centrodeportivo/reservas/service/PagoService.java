package com.centrodeportivo.reservas.service;

import com.centrodeportivo.reservas.exception.NotFoundException;
import com.centrodeportivo.reservas.model.Pago;
import com.centrodeportivo.reservas.repository.PagoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PagoService {

    private final PagoRepository pagoRepository;

    public List<Pago> listar() {
        return pagoRepository.findAll().stream()
                .sorted(Comparator.comparing(Pago::getId))
                .toList();
    }

    public Pago obtener(Long id) {
        return pagoRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Pago no encontrado"));
    }

    public Pago crear(Pago p) {
        return pagoRepository.save(p);
    }

    public Pago actualizar(Long id, Pago p) {
        p.setId(id);
        return pagoRepository.save(p);
    }

    public void eliminar(Long id) {
        pagoRepository.deleteById(id);
    }
}
