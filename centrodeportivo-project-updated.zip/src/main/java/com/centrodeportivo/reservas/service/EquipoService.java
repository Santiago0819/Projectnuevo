package com.centrodeportivo.reservas.service;

import com.centrodeportivo.reservas.exception.NotFoundException;
import com.centrodeportivo.reservas.model.Equipo;
import com.centrodeportivo.reservas.repository.EquipoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EquipoService {

    private final EquipoRepository equipoRepository;

    public List<Equipo> listar() {
        return equipoRepository.findAll().stream()
                .sorted(Comparator.comparing(Equipo::getId))
                .toList();
    }

    public Equipo obtener(Long id) {
        return equipoRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Equipo no encontrado"));
    }

    public Equipo crear(Equipo e) {
        return equipoRepository.save(e);
    }

    public Equipo actualizar(Long id, Equipo e) {
        e.setId(id);
        return equipoRepository.save(e);
    }

    public void eliminar(Long id) {
        equipoRepository.deleteById(id);
    }
}
