package com.centrodeportivo.reservas.service;

import com.centrodeportivo.reservas.exception.NotFoundException;
import com.centrodeportivo.reservas.model.Servicio;
import com.centrodeportivo.reservas.repository.ServicioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ServicioService {

    private final ServicioRepository servicioRepository;

    public List<Servicio> listar() {
        return servicioRepository.findAll().stream()
                .sorted(Comparator.comparing(Servicio::getId))
                .toList();
    }

    public Servicio obtener(Long id) {
        return servicioRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Servicio no encontrado"));
    }

    public Servicio crear(Servicio s) {
        return servicioRepository.save(s);
    }

    public Servicio actualizar(Long id, Servicio s) {
        s.setId(id);
        return servicioRepository.save(s);
    }

    public void eliminar(Long id) {
        servicioRepository.deleteById(id);
    }
}
