package com.centrodeportivo.reservas.controller;

import com.centrodeportivo.reservas.model.Instalacion;
import com.centrodeportivo.reservas.service.InstalacionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/instalaciones")
@RequiredArgsConstructor
public class InstalacionController {

    private final InstalacionService instalacionService;

    @GetMapping
    public List<Instalacion> listar() {
        return instalacionService.listar();
    }

    @GetMapping("/{id}")
    public Instalacion obtener(@PathVariable Long id) {
        return instalacionService.obtener(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Instalacion crear(@RequestBody Instalacion i) {
        return instalacionService.crear(i);
    }

    @PutMapping("/{id}")
    public Instalacion actualizar(@PathVariable Long id, @RequestBody Instalacion i) {
        return instalacionService.actualizar(id, i);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Long id) {
        instalacionService.eliminar(id);
    }
}
