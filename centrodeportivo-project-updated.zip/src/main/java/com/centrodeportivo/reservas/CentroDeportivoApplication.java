package com.centrodeportivo.reservas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CentroDeportivoApplication {

    public static void main(String[] args) {
        SpringApplication.run(CentroDeportivoApplication.class, args);
    }
}
