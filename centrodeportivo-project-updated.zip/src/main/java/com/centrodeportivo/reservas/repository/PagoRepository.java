package com.centrodeportivo.reservas.repository;

import com.centrodeportivo.reservas.model.Pago;
import com.centrodeportivo.reservas.model.enums.MetodoPago;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

@Repository
public class PagoRepository extends CsvRepository<Pago> {

    public PagoRepository() {
        super("pagos.csv");
    }

    @Override
    protected String getHeaders() {
        return "id;reservaId;metodo;monto;fechaHora";
    }

    @Override
    protected String toCsvRow(Pago p) {
        return String.join(";",
                String.valueOf(p.getId()),
                String.valueOf(p.getReservaId()),
                p.getMetodo() == null ? "" : p.getMetodo().name(),
                String.valueOf(p.getMonto()),
                p.getFechaHora() == null ? "" : p.getFechaHora().toString()
        );
    }

    @Override
    protected Pago fromCsvRow(String row) {
        String[] p = row.split(";");
        Pago pago = new Pago();
        pago.setId(Long.parseLong(p[0]));
        pago.setReservaId(Long.parseLong(p[1]));
        if (!p[2].isBlank()) {
            pago.setMetodo(MetodoPago.valueOf(p[2]));
        }
        pago.setMonto(Double.parseDouble(p[3]));
        if (p.length > 4 && !p[4].isBlank()) {
            pago.setFechaHora(LocalDateTime.parse(p[4]));
        }
        return pago;
    }
}
