package com.centrodeportivo.reservas.repository;

import com.centrodeportivo.reservas.model.Equipo;
import org.springframework.stereotype.Repository;

@Repository
public class EquipoRepository extends CsvRepository<Equipo> {

    public EquipoRepository() {
        super("equipos.csv");
    }

    @Override
    protected String getHeaders() {
        return "id;nombre;disponible";
    }

    @Override
    protected String toCsvRow(Equipo e) {
        return String.join(";",
                String.valueOf(e.getId()),
                e.getNombre(),
                String.valueOf(e.isDisponible())
        );
    }

    @Override
    protected Equipo fromCsvRow(String row) {
        String[] p = row.split(";");
        Equipo e = new Equipo();
        e.setId(Long.parseLong(p[0]));
        e.setNombre(p[1]);
        e.setDisponible(Boolean.parseBoolean(p[2]));
        return e;
    }
}
