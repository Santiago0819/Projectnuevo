package com.centrodeportivo.reservas.repository;

public interface CsvEntity {
    Long getId();
    void setId(Long id);
}
