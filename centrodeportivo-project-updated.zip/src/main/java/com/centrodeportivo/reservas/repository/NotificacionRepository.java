package com.centrodeportivo.reservas.repository;

import com.centrodeportivo.reservas.model.Notificacion;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

@Repository
public class NotificacionRepository extends CsvRepository<Notificacion> {

    public NotificacionRepository() {
        super("notificaciones.csv");
    }

    @Override
    protected String getHeaders() {
        return "id;usuarioId;mensaje;fechaHora;leida";
    }

    @Override
    protected String toCsvRow(Notificacion n) {
        return String.join(";",
                String.valueOf(n.getId()),
                String.valueOf(n.getUsuarioId()),
                n.getMensaje(),
                n.getFechaHora() == null ? "" : n.getFechaHora().toString(),
                String.valueOf(n.isLeida())
        );
    }

    @Override
    protected Notificacion fromCsvRow(String row) {
        String[] p = row.split(";");
        Notificacion n = new Notificacion();
        n.setId(Long.parseLong(p[0]));
        n.setUsuarioId(Long.parseLong(p[1]));
        n.setMensaje(p[2]);
        if (p.length > 3 && !p[3].isBlank()) {
            n.setFechaHora(LocalDateTime.parse(p[3]));
        }
        n.setLeida(Boolean.parseBoolean(p[4]));
        return n;
    }
}
