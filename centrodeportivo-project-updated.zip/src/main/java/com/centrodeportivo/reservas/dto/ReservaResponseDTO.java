package com.centrodeportivo.reservas.dto;

import com.centrodeportivo.reservas.model.enums.EstadoReserva;

import java.time.LocalDate;
import java.time.LocalTime;

public record ReservaResponseDTO(
        Long id,
        Long usuarioId,
        Long instalacionId,
        LocalDate fecha,
        LocalTime horaInicio,
        LocalTime horaFin,
        double precioTotal,
        EstadoReserva estado
) {}
