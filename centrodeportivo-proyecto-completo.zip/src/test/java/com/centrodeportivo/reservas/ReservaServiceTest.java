package com.centrodeportivo.reservas;

import com.centrodeportivo.reservas.model.Factura;
import com.centrodeportivo.reservas.model.Instalacion;
import com.centrodeportivo.reservas.model.Reserva;
import com.centrodeportivo.reservas.model.Socio;
import com.centrodeportivo.reservas.model.enums.EstadoReserva;
import com.centrodeportivo.reservas.model.enums.TipoInstalacion;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;

public class ReservaServiceTest {

    @Test
    void testSolapamientoReservas() {
        Reserva r1 = new Reserva();
        r1.setInstalacionId(1L);
        r1.setFecha(LocalDate.of(2025, 1, 1));
        r1.setHoraInicio(LocalTime.of(10, 0));
        r1.setHoraFin(LocalTime.of(11, 0));
        r1.setEstado(EstadoReserva.CONFIRMADA);

        Reserva r2 = new Reserva();
        r2.setInstalacionId(1L);
        r2.setFecha(LocalDate.of(2025, 1, 1));
        r2.setHoraInicio(LocalTime.of(10, 30));
        r2.setHoraFin(LocalTime.of(11, 30));

        Assertions.assertTrue(r1.seSolapaCon(r2));
    }

    @Test
    void testNoSolapamientoInstalacionDistinta() {
        Reserva r1 = new Reserva();
        r1.setInstalacionId(1L);
        r1.setFecha(LocalDate.now());
        r1.setHoraInicio(LocalTime.of(10, 0));
        r1.setHoraFin(LocalTime.of(11, 0));

        Reserva r2 = new Reserva();
        r2.setInstalacionId(2L);
        r2.setFecha(r1.getFecha());
        r2.setHoraInicio(LocalTime.of(10, 30));
        r2.setHoraFin(LocalTime.of(11, 30));

        Assertions.assertFalse(r1.seSolapaCon(r2));
    }

    @Test
    void testDescuentoSocioGold() {
        Socio socio = new Socio();
        socio.setNivelMembresia("GOLD");
        double base = 100.0;
        double descuento = socio.calcularDescuento(base);
        Assertions.assertEquals(20.0, descuento);
    }

    @Test
    void testDescuentoSocioSilver() {
        Socio socio = new Socio();
        socio.setNivelMembresia("SILVER");
        double base = 100.0;
        double descuento = socio.calcularDescuento(base);
        Assertions.assertEquals(10.0, descuento);
    }

    @Test
    void testDescuentoSocioSinMembresia() {
        Socio socio = new Socio();
        socio.setNivelMembresia("BRONZE");
        double base = 100.0;
        double descuento = socio.calcularDescuento(base);
        Assertions.assertEquals(0.0, descuento);
    }

    @Test
    void testInstalacionTarifaHora() {
        Instalacion inst = new Instalacion();
        inst.setTarifaHora(50.0);
        Assertions.assertEquals(50.0, inst.getTarifaHora());
    }

    @Test
    void testFacturaCalcularTotal() {
        Factura f = new Factura();
        f.setSubtotal(200.0);
        f.setDescuento(50.0);
        Assertions.assertEquals(150.0, f.calcularTotal());
    }

    @Test
    void testTipoInstalacionEnum() {
        TipoInstalacion tipo = TipoInstalacion.CANCHA_FUTBOL;
        Assertions.assertEquals("CANCHA_FUTBOL", tipo.name());
    }
}
