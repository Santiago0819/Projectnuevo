package com.centrodeportivo.reservas.model.interfaces;

public interface Notificable {
    void notificar(String mensaje);
}
