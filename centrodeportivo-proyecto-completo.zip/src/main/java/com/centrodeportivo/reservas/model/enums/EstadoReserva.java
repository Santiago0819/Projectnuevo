package com.centrodeportivo.reservas.model.enums;

public enum EstadoReserva {
    PENDIENTE,
    CONFIRMADA,
    CANCELADA
}
