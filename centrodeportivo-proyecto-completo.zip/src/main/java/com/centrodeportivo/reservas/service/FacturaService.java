package com.centrodeportivo.reservas.service;

import com.centrodeportivo.reservas.exception.NotFoundException;
import com.centrodeportivo.reservas.model.Factura;
import com.centrodeportivo.reservas.repository.FacturaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FacturaService {

    private final FacturaRepository facturaRepository;

    public List<Factura> listar() {
        return facturaRepository.findAll().stream()
                .sorted(Comparator.comparing(Factura::getId))
                .toList();
    }

    public Factura obtener(Long id) {
        return facturaRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Factura no encontrada"));
    }

    public Factura crear(Factura f) {
        return facturaRepository.save(f);
    }

    public Factura actualizar(Long id, Factura f) {
        f.setId(id);
        return facturaRepository.save(f);
    }

    public void eliminar(Long id) {
        facturaRepository.deleteById(id);
    }
}
