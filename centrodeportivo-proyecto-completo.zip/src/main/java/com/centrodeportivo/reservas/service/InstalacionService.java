package com.centrodeportivo.reservas.service;

import com.centrodeportivo.reservas.exception.NotFoundException;
import com.centrodeportivo.reservas.model.Instalacion;
import com.centrodeportivo.reservas.repository.InstalacionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class InstalacionService {

    private final InstalacionRepository instalacionRepository;

    public List<Instalacion> listar() {
        return instalacionRepository.findAll().stream()
                .sorted(Comparator.comparing(Instalacion::getId))
                .toList();
    }

    public Instalacion obtener(Long id) {
        return instalacionRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Instalación no encontrada"));
    }

    public Instalacion crear(Instalacion i) {
        return instalacionRepository.save(i);
    }

    public Instalacion actualizar(Long id, Instalacion i) {
        i.setId(id);
        return instalacionRepository.save(i);
    }

    public void eliminar(Long id) {
        instalacionRepository.deleteById(id);
    }
}
