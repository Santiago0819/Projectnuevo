package com.centrodeportivo.reservas.service;

import com.centrodeportivo.reservas.exception.NotFoundException;
import com.centrodeportivo.reservas.model.Notificacion;
import com.centrodeportivo.reservas.repository.NotificacionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificacionService {

    private final NotificacionRepository notificacionRepository;

    public List<Notificacion> listarPorUsuario(Long usuarioId) {
        return notificacionRepository.findAll().stream()
                .filter(n -> n.getUsuarioId().equals(usuarioId))
                .sorted(Comparator.comparing(Notificacion::getFechaHora))
                .toList();
    }

    public Notificacion crear(Long usuarioId, String mensaje) {
        Notificacion n = new Notificacion();
        n.setUsuarioId(usuarioId);
        n.setMensaje(mensaje);
        n.setFechaHora(LocalDateTime.now());
        n.setLeida(false);
        return notificacionRepository.save(n);
    }

    public Notificacion marcarLeida(Long id) {
        Notificacion n = notificacionRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Notificación no encontrada"));
        n.setLeida(true);
        return notificacionRepository.save(n);
    }
}
