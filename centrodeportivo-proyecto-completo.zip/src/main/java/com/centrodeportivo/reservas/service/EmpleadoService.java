package com.centrodeportivo.reservas.service;

import com.centrodeportivo.reservas.exception.NotFoundException;
import com.centrodeportivo.reservas.model.Empleado;
import com.centrodeportivo.reservas.repository.EmpleadoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EmpleadoService {

    private final EmpleadoRepository empleadoRepository;

    public List<Empleado> listar(int page, int size) {
        List<Empleado> todos = empleadoRepository.findAll().stream()
                .sorted(Comparator.comparing(Empleado::getId))
                .toList();
        int from = Math.min(page * size, todos.size());
        int to = Math.min(from + size, todos.size());
        return todos.subList(from, to);
    }

    public Empleado obtener(Long id) {
        return empleadoRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Empleado no encontrado"));
    }

    public Empleado crear(Empleado e) {
        return empleadoRepository.save(e);
    }

    public Empleado actualizar(Long id, Empleado e) {
        e.setId(id);
        return empleadoRepository.save(e);
    }

    public void eliminar(Long id) {
        empleadoRepository.deleteById(id);
    }
}
