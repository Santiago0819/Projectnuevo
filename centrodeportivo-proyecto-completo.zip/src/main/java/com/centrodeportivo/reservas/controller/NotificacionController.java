package com.centrodeportivo.reservas.controller;

import com.centrodeportivo.reservas.model.Notificacion;
import com.centrodeportivo.reservas.service.NotificacionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notificaciones")
@RequiredArgsConstructor
public class NotificacionController {

    private final NotificacionService notificacionService;

    @GetMapping("/usuario/{usuarioId}")
    public List<Notificacion> listarPorUsuario(@PathVariable Long usuarioId) {
        return notificacionService.listarPorUsuario(usuarioId);
    }

    @PostMapping("/usuario/{usuarioId}")
    @ResponseStatus(HttpStatus.CREATED)
    public Notificacion crear(@PathVariable Long usuarioId, @RequestParam String mensaje) {
        return notificacionService.crear(usuarioId, mensaje);
    }

    @PostMapping("/{id}/leer")
    public Notificacion marcarLeida(@PathVariable Long id) {
        return notificacionService.marcarLeida(id);
    }
}
