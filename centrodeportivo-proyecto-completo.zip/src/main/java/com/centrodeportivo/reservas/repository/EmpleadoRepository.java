package com.centrodeportivo.reservas.repository;

import com.centrodeportivo.reservas.model.Empleado;
import org.springframework.stereotype.Repository;

@Repository
public class EmpleadoRepository extends CsvRepository<Empleado> {

    public EmpleadoRepository() {
        super("empleados.csv");
    }

    @Override
    protected String getHeaders() {
        return "id;nombre;email;telefono;cargo;salario";
    }

    @Override
    protected String toCsvRow(Empleado e) {
        return String.join(";",
                String.valueOf(e.getId()),
                e.getNombre(),
                e.getEmail(),
                e.getTelefono(),
                e.getCargo() == null ? "" : e.getCargo(),
                String.valueOf(e.getSalario())
        );
    }

    @Override
    protected Empleado fromCsvRow(String row) {
        String[] p = row.split(";");
        Empleado e = new Empleado();
        e.setId(Long.parseLong(p[0]));
        e.setNombre(p[1]);
        e.setEmail(p[2]);
        e.setTelefono(p[3]);
        e.setCargo(p[4]);
        e.setSalario(Double.parseDouble(p[5]));
        return e;
    }
}
