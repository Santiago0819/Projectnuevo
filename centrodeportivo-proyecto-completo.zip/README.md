# Sistema de Gestión de Reservas y Recursos para un Centro Deportivo

## Requisitos

- JDK 23+
- Maven 3.8+
- IntelliJ IDEA (recomendado)

## Compilación y ejecución

```bash
mvn clean package
mvn spring-boot:run
```

La aplicación se ejecuta en: `http://localhost:8080`.

## Endpoints principales

- `GET /api/socios`
- `POST /api/socios`
- `GET /api/empleados`
- `GET /api/instalaciones`
- `GET /api/equipos`
- `GET /api/servicios`
- `GET /api/reservas`
- `POST /api/reservas`
- `POST /api/reservas/{id}/cancelar`
- `GET /api/facturas`
- `GET /api/pagos`
- `GET /api/notificaciones/usuario/{usuarioId}`

## Documentación de la API

Swagger UI:

- `http://localhost:8080/swagger-ui.html`

## Persistencia CSV

Carpeta `data/` con un archivo por entidad:

- `socios.csv`
- `empleados.csv`
- `instalaciones.csv`
- `equipos.csv`
- `servicios.csv`
- `reservas.csv`
- `facturas.csv`
- `pagos.csv`
- `notificaciones.csv`

Las relaciones se manejan por id. Por ejemplo, `reservas.csv` contiene `usuarioId` e `instalacionId`.
