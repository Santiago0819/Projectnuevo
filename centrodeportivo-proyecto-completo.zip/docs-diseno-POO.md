# Diseño Orientado a Objetos del Sistema de Reservas

## Encapsulamiento

Las entidades (`Socio`, `Empleado`, `Reserva`, `Instalacion`, etc.) definen sus atributos como privados y usan Lombok (`@Data`) para exponer getters y setters, protegiendo el estado interno.

## Herencia y clases abstractas

`Usuario` es una clase abstracta que representa un usuario genérico del sistema. `Socio` y `Empleado` heredan de ella y comparten campos como `id`, `nombre`, `email` y `telefono`.

## Polimorfismo

`Usuario` declara el método abstracto:

```java
public abstract double calcularDescuento(double tarifaBase);
```

`Socio` y `Empleado` lo implementan de manera diferente. `ReservaService` invoca este método sin conocer el tipo concreto de usuario, aplicando polimorfismo en tiempo de ejecución.

## Interfaces

Se definen las interfaces:

- `Notificable`: representa objetos capaces de recibir notificaciones.
- `Pagable`: define `calcularTotal()` para entidades relacionadas con pagos.

`Factura` implementa `Pagable` y calcula su total a partir de `subtotal` y `descuento`.

## Composición y agregación

`Reserva` mantiene referencias a `usuarioId`, `instalacionId` y una lista de `equiposIds`. La reserva solo tiene sentido con estas entidades asociadas, modelando composición/agregación.  
`Instalacion` contiene una colección de `equiposIds`, indicando que una instalación utiliza varios equipos (agregación).

## Enums

Se usan enums para modelar estados y tipos fijos:

- `TipoInstalacion`
- `EstadoReserva`
- `MetodoPago`
- `RolUsuario`

## Records

`ReservaResponseDTO` es un `record` que actúa como DTO inmutable de respuesta REST, aprovechando características modernas de Java.

## Persistencia y patrón repositorio

La interfaz `CsvEntity` identifica entidades persistibles en CSV.  
`CsvRepository<T>` implementa la lógica genérica de lectura/escritura en CSV y los repositorios concretos solo definen el mapeo entre filas y objetos.

## Reglas de negocio

En `ReservaService` se implementan, entre otras, las siguientes reglas:

- No permitir reservas solapadas para la misma instalación (método `seSolapaCon`).
- Calcular la tarifa según duración y tarifa por hora de la instalación.
- Aplicar descuentos según el tipo de socio y nivel de membresía.
- Limitar el número máximo de equipos prestados por socio.

Con esto se cubren los requisitos de POO avanzado, diseño por capas y reglas de negocio del sistema.
